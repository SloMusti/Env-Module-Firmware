# BQ34Z100
Library for the BQ34Z100(-G1) IC from Texas Instruments for the Arduino platform.
